For Librarian Admin Panel:
Username: adminac
Password: testing321

For Django Admin Panel:
Username: admin
Password: testing321